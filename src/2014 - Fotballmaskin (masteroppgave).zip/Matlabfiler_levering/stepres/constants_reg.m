Kp_m1=13.3387
Ki_m1=0.048853
Kd_m1=0.0005

Kp_m2=10
Ki_m2=amp_m2*Kp_m2+1/timeconst_2_mean
Kd_m2=Ki_m2/4