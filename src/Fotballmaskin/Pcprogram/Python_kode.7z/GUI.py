from Tkinter import *
#import tkFiledialog
        #from ttk import *
from Kontroll import Communication


class KontrollPanel(Frame):
        def __init__(self,master=None):
                Frame.__init__(self,master,relief="groove")
                self.master=master
                self.grid()
                self.com=Communication()
                self.master.protocol('WM_DELETE_WINDOW', self.exit_panel)
                self.checkspinn=BooleanVar()
                self.checkstrom=BooleanVar()
                self.checkspeed_m1=BooleanVar()
                self.checkspeed_m2=BooleanVar()

                self.loggingnavn=StringVar()
                self.samplerate=IntVar()
                self.duration=IntVar()
                self.fartvar=DoubleVar()
                self.spinvar=DoubleVar()
                self.ballchoicevar=IntVar()
                self.createWidgets()

        def createWidgets(self):
                self.ballframe=Frame(self)
                self.ballframe.grid(row=0,column=0)
                
                Label(self.ballframe,text='Fart').grid(row=0,column=0)
                Entry(self.ballframe,textvariable=self.fartvar).grid(row=0,column=1)
                Label(self.ballframe,text='Spinn').grid(row=0,column=2)
                Entry(self.ballframe,textvariable=self.spinvar).grid(row=0,column=3)
                self.spinncheck=Checkbutton(self.ballframe,text="Spinn",variable=self.checkspinn)
                self.spinncheck.grid(row=1,column=0)
                self.ButtonFrame=Frame(self.ballframe)
                self.ButtonFrame.grid(row=2,column=0)
                self.speedButton=Button(self.ButtonFrame,text="Sett fart",command=self.set_speed)
                self.speedButton.grid(row=0,column=0)
                self.resetspeedButton=Button(self.ButtonFrame,text="Nullstill",command=self.zero_speed)
                self.resetspeedButton.grid(row=0,column=1)
                self.calibrateButton=Button(self.ButtonFrame,text="Kalibrer", command=self.calibrate)
                self.calibrateButton.grid(row=0,column=2)
		#self.choose_ball=Button(self.ButtonFrame,text='Ballmeny',command=self.choose_ball_menu)
                                
                self.loggframe=Frame(self)
                self.loggframe.grid(row=0,column=1)
                self.loggSM1check=Checkbutton(self.loggframe,text="strom",variable=self.checkstrom,command=self.update_loggingflags)
               
                self.loggFM1check=Checkbutton(self.loggframe,text="fart m1",variable=self.checkspeed_m1,command=self.update_loggingflags)
                self.loggFM2check=Checkbutton(self.loggframe,text="fart m2",variable=self.checkspeed_m2,command=self.update_loggingflags)
                self.loggSM1check.grid(row=0,column=0)
            
                self.loggFM1check.grid(row=1,column=0)
                self.loggFM2check.grid(row=1,column=1)

                self.loggbutton=Button(self.loggframe,text='Logg',command=self.start_logging)
                self.loggkonfig=Button(self.loggframe,text='Konfig Logging',command=self.config_logging_window)
                self.loggbutton.grid(row=2,column=0)
                self.loggkonfig.grid(row=2,column=1)
                
        def config_logging_window(self):
                self.config=Toplevel()
                self.config.title('Konfigurasjoner av loggingen av systemet')
                Label(self.config,text='Navn').grid(row=0,column=0,sticky=W+N+E+S)
                Entry(self.config,textvariable=self.loggingnavn).grid(row=0,column=1,sticky=W+N+E+S)
                Label(self.config,text="Samplerate").grid(row=1,column=0,sticky=W+N+E+S)
                Entry(self.config,textvariable=self.samplerate).grid(row=1,column=1,sticky=W+N+E+S)
                Label(self.config,text='Varighet').grid(row=2,column=0,sticky=W+N+E+S)
                Entry(self.config,textvariable=self.duration).grid(row=2,column=1,sticky=W+N+E+S)
                Button(self.config,text='OK',command=self.exit_config).grid(row=3,column=0,sticky=W+N+E+S)
        #def choose_ball_menu(self):
        #        self.ballmenu=Toplevel()
        #        self.ballmenu.title('Ballmeny'):
        #        Button(self.ballmenu,text='last ball',command=self.update_ball_list).grid(row=0,column=0)
        #        self.make_radio_buttonlist(self.ballmenu)
        def update_ball_list(self):
                adress=tkFileDialog.askopenfilename()
                self.com.load_ball(adress)
                self.make_radio_buttonlist(self.ballmenu)
        def make_radio_buttonlist(self,master):
                for i,ball in enumerate(self.com.Ball_list):
                        Radiobutton(master,text=str(ball.name),variable=self.ballchoicevar,value=i,command=self.update_active_ball).grid(row=i+1,column=0)
                
        def update_active_ball(self):
                self.com.set_active_ball(self.ballchoicevar.get())
        def calibrate(self):
                calibM1,calibM2=self.com.calibrate_motors(self.fartvar.get())

        def start_logging(self):
                if not self.com.is_collecting():
                        self.com.start_collector()
                self.com.start_collecting()
        def update_loggingflags():
                self.com.set_loggingflags(self.checkspeed_m1.get(),self.checkspeed_m2.get(),self.checkstrom.get())       
        def set_speed(self):
  
                if self.fartvar.get()<=0:
                        print("maa oppgi en gyldig hastighet!")
                        return False
                
                elif self.checkspinn.get():
                        self.com.set_spinn_and_velocity_ball(self.spinvar.get(),self.fartvar.get())
                        print("satt hastighet og spinn")
                        return True
                else:
                        self.com.set_speed_ball(self.fartvar.get())
                        print("satt hastighet uten spinn")
                        return True
                        
                        
        def zero_speed(self):
                self.com.set_speed_ball(0)
                return True
        
      

        def exit_config(self):
                print("placeholder")
                self.update_configvars()

                self.config.destroy()
        def update_configvars(self):
                print("placeholder")
                self.com.set_samplerate(self.samplerate.get())
                self.com.set_duration(self.duration.get())
                self.com.set_name(self.loggingnavn.get())
        
        def exit_panel(self):
                self.zero_speed()
                self.com.close()
                if self.master==None:
                        self.destroy()
                else:
                        self.master.destroy()
##class GUI(Frame):
##        def __init__(self,master=None):
##                Frame.__init__(self,master)
##                self.grid()
##                self.createWidgets()
##                
##        def createWidgets(self):
##                #f1=Frame(self)
##                #f2=Frame(self)
##
##                #self.ShotControl=ShotControl(f1)
##                #self.BallControl=BallControl(f1)
##                #self.ShotControl.grid(row=1,column=0,sticky=W+E+N+S)
##                #self.BallControl.grid(row=1,column=1,sticky=W+E+N+S)
##                self.KontrollPanel=KontrollPanel(self)
##                self.KontrollPanel.grid(sticky=W+E+N+S)
##                #self.add(f1,text='Kontroll')
##                #self.add(f2,text='Plot')
##                #self.grid(sticky=W+E+N+S)
##
##class Pointentry(Frame):
##        def toggle_entry(self):
##                if self.checkvar.get()==0:
##                        self.Entry.configure(state='disabled')
##                        self.var.set(0)
##                else:
##                        self.Entry.configure(state='normal')
##
##        def createWidgets(self,name,var,checkvar):
##                self.Text=Label(self,text=name)
##                self.Entry=Entry(self,textvariable=var)
##                self.Check=Checkbutton(self,text="Toggle",variable=self.checkvar,command=self.toggle_entry)
##                
##                self.Text.grid(row=0,column=0)
##                self.Entry.grid(row=0,column=1)
##                self.Check.grid(row=0,column=2)
##
##        def __init__(self,master=None,name='Noname',var=None,checkvar=None):
##                Frame.__init__(self, master)
##                self.var=var
##                self.checkvar=checkvar
##                self.grid()
##                self.createWidgets(name,var,checkvar)
##class Shotlist(Frame):
##        def __init__(self,master=None):
##                Frame.__init__(self,master,relief="groove")
##                self.grid()
##                self.namelist=[]
##                self.checkshots=[]
##                self.shots=[]
##                self.createWidgets()
##                
##        def createWidgets(self):
##                Label(self,text='Name').grid(row=0,column=0)
##                Label(self,text='Angle').grid(row=0,column=1)
##                Label(self,text='V (m/s)').grid(row=0,column=2)
##                self.addshot(20,20)
##        def addshot(self,speed,angle):
##                self.namelist.append(StringVar())
##                self.shots.append(Frame(self))
##                self.checkshots.append(BooleanVar())
##                self.checkshots[-1].set(1)
##                Entry(self,textvariable=self.namelist[-1]).grid(row=len(self.shots),column=0)
##                Label(self,text=str(angle),background="white",relief="sunken").grid(row=len(self.shots),column=1)
##                Label(self,text=str(speed)).grid(row=len(self.shots),column=2)
##                Checkbutton(self,variable=self.checkshots[-1],command=self.toggle_something).grid(row=len(self.shots),column=3)
##                self.shots[-1].grid(row=len(self.shots),column=0)
##        def toggle_something(self):
##                print "something"
##        #def update_shotlist(self):
##                
###class PlotModule(Frame):
        
##class BallControl(Frame):
##        def __init__(self,master=None):
##                Frame.__init__(self,master,relief="groove")
##                self.grid()
##                self.activeBall=StringVar()
##                self.activeKd=DoubleVar()
##                self.activeKw=DoubleVar()
##                self.createWidgets()
##        
##
##        def createWidgets(self):
##                self.title=Label(self,text="Ball: "+str(self.activeBall.get()))
##                self.title.grid(row=0,column=0,sticky=W+E+N+S)
##                
##                self.const=Frame(self)
##                Label(self.const,text="Kd").grid(row=0,column=0)
##                Label(self.const,text=str(self.activeKd.get()),background="white",relief="sunken").grid(row=0,column=1)
##                Label(self.const,text="Kw").grid(row=0,column=2)
##                Label(self.const,text=str(self.activeKw.get()),background="white",relief="sunken").grid(row=0,column=3)
##                self.const.grid(row=1,column=0,sticky=W+E+N+S)
##                
##                self.buttons=Frame(self)
##                self.calib=Button(self.buttons,text="Calibrate",command=self.Calibrate)
##                self.nyball=Button(self.buttons,text="New Ball", command=self.New_ball)
##                self.hentball=Button(self.buttons,text="Get Ball",command=self.Get_ball)
##
##                self.nyball.grid(row=0,column=1)
##                self.hentball.grid(row=0,column=2)
##                self.calib.grid(row=0,column=0)
##                self.buttons.grid(row=2,column=0,sticky=W+E+N+S)
##
##        def Calibrate(self):
##                print "Calibrating placeholder"
##        def New_ball(self):
##                print "New ball placeholder"
##        def Get_ball(self):
##                print "Get ball placeholder"
##
####class Controllpanel(Frame):
####        def __init__(self,master=None):
####                Frame.__init__(self,master)
####                self.grid()
####                self.createWidgets()
####        def createWidgets(self):
####                self.BallControl=BallControl(self)
####                self.ShotControl=ShotControl(self)
####
####                self.ShotControl.grid(row=0,column=0,sticky=W+E+N+S)
####                self.BallControl.grid(row=0,column=1,sticky=W+E+N+S)
##
##class PointModule(Frame):
##        def findSpeedandAngle(self):
##                print "X: "+str(self.x.get())
##                print "Y: "+str(self.y.get())
##                print "Z: "+str(self.z.get())
##        def clearPoints(self):
##                self.x.set(0)
##                self.y.set(0)
##                self.z.set(0)
##        def createWidgets(self):
##                self.Xentry=Pointentry(self,'X',self.x,self.xcheck)
##                self.Xentry.grid(row=0,column=0)
##                self.Yentry=Pointentry(self,'Y',var=self.y,checkvar=self.ycheck)
##                self.Yentry.grid(row=1,column=0)
##                self.Zentry=Pointentry(self,'Z',self.z,self.zcheck)
##                self.Zentry.grid(row=2,column=0)
##                self.Buttons=Frame(self)
##                
##                self.CalcButton=Button(self.Buttons,text='Calculate',command=self.findSpeedandAngle)
##                self.CalcButton.grid(row=0,column=0)
##                self.ClearButton=Button(self.Buttons,text='Clear',command=self.clearPoints)
##                self.ClearButton.grid(row=0,column=1)
##                self.Buttons.grid(row=3,column=0)
##        def __init__(self,master=None):
##                Frame.__init__(self,master)
##                self.grid()
##
##                self.x=DoubleVar(0)
##                self.y=DoubleVar(0)
##                self.z=DoubleVar(0)
##                self.xcheck=BooleanVar()
##                self.xcheck.set(1)
##                self.ycheck=BooleanVar()
##                self.ycheck.set(1)
##                self.zcheck=BooleanVar()
##                self.zcheck.set(1)
##                self.createWidgets()
root = Tk()
app = KontrollPanel(root)
app.grid(sticky=W+E+N+S)


app.mainloop()

